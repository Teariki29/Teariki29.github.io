<?php
	$server = 'servbdd';
	$driver = 'pgsql';
	$dbname = 'pg_marlemoal';
	$user   = 'marlemoal';
	$pass	= '0C529d48!';
?>