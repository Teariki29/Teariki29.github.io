function ouvreModal() {
    document.getElementById('myModal2').style.display = 'block';
}

function fermeModal() {
    document.getElementById('myModal2').style.display = 'none';
}

