function modalRedirect() {
    document.getElementById('myModal4').style.display = 'block';
}

function refusRedirect() {
    document.getElementById('myModal4').style.display = 'none';
}

function modalRedirect2() {
    document.getElementById('myModal5').style.display = 'block';
}

function refusRedirect2() {
    document.getElementById('myModal5').style.display = 'none';
}

function modalRedirect3() {
    document.getElementById('myModal6').style.display = 'block';
}

function refusRedirect3() {
    document.getElementById('myModal6').style.display = 'none';
}


