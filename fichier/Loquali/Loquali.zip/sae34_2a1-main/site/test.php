<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire</title>
</head>
<body>

    <form action="demandeDevis.php" method="post">
        <input type="hidden" name="id" value="1">
        <input type="hidden" name="qui" value="proprietaire">
        <input type="hidden" name="idResrvation" value="4">
        <button type="submit">Envoyer la demande de devis</button>
    </form>

</body>
</html>
