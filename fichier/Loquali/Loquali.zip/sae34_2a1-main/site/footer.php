<footer>

<div id="infosFooter">
  <div id="footerCercleLogo">
    <img src="asset/img/logoRond.svg" alt="logo">
  </div>
  <div id="textefooter">
    <div id="infosLegal">
      <h2>Informations légales</h2>
      <ul>
        <li><a href="">Plan du site</a></li>
        <li><a href="mentionsLegales.php">Mentions légales</a></li>
        <li><a href="cgv.php">Conditions générales de ventes</a></li>
        <li><a href="cgu.php">Conditions générales d'utilisation</a></li>
        <li><a href="">Truc utile a savoir</a></li>
      </ul>
    </div>
    <div id="support">
      <h2>Support client</h2>
      <a href="">Contacter le support</a>
    </div>
    <div id="reseaux">
      <h2>Suivez nous</h2>
      <div id="logoReseaux">
        <a href=""><img src="asset/icons/blanc/facebook.svg" alt=""></a>
        <a href=""><img src="asset/icons/blanc/instagram.svg" alt=""></a>
        <a href=""><img src="asset/icons/blanc/steam.svg" alt=""></a>
      </div>
    </div>
    <div id="contact">
      <h2>Nous contacter</h2>
      <p>Rue Édouard Branly, 22300 Lannion</p>
      <p>02 96 46 93 00</p>
      <p>iut-lannion.univ-rennes.fr</p>
    </div>
  </div>
</div>

<div class="basFooter">
  <p>Copyright @ 2023 LoQuali.com</p>
</div>

</footer>