# Répartition des tâches

## Protocole :
- Colin : 100%

## Serveur (codage et tests)
- Colin : 100%

## Client (codage et tests)
- Alexandre 90%
- Colin : 10%

## Page web de gestion
- Alexandre : 90%
- Colin : 10%

## Documentation
- Colin : 100%