# Liste des types d'évènements ICALator
- Indisponible : Le logement a été désactivé sur ce jour
- Réservation : Le logement a été réservé sur cette période
- Demande de réservation : Une demande de réservation a été faite sur cette période