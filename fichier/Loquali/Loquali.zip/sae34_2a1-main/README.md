# Loquali

## Liens importants
- https://online.visual-paradigm.com/share.jsp?id=323036313438352d33